
rm(list = ls()) #clear workspace
# Load libraries
library(caret)
library(ggplot2)
library(Metrics)
library(tidyverse)
library(knitr)
library(lubridate)
library(janitor)



##########################################################
# Create edx and final_holdout_test sets 
##########################################################

# Note: this process could take a couple of minutes

if(!require(tidyverse)) install.packages("tidyverse", repos = "http://cran.us.r-project.org")
if(!require(caret)) install.packages("caret", repos = "http://cran.us.r-project.org")

library(tidyverse)
library(caret)

# MovieLens 10M dataset:
# https://grouplens.org/datasets/movielens/10m/
# http://files.grouplens.org/datasets/movielens/ml-10m.zip

options(timeout = 600)

dl <- "ml-10M100K.zip"
if(!file.exists(dl))
  download.file("https://files.grouplens.org/datasets/movielens/ml-10m.zip", dl)

ratings_file <- "ml-10M100K/ratings.dat"
if(!file.exists(ratings_file))
  unzip(dl, ratings_file)

movies_file <- "ml-10M100K/movies.dat"
if(!file.exists(movies_file))
  unzip(dl, movies_file)

ratings <- as.data.frame(str_split(read_lines(ratings_file), fixed("::"), simplify = TRUE),
                         stringsAsFactors = FALSE)
colnames(ratings) <- c("userId", "movieId", "rating", "timestamp")
ratings <- ratings %>%
  mutate(userId = as.integer(userId),
         movieId = as.integer(movieId),
         rating = as.numeric(rating),
         timestamp = as.integer(timestamp))

movies <- as.data.frame(str_split(read_lines(movies_file), fixed("::"), simplify = TRUE),
                        stringsAsFactors = FALSE)
colnames(movies) <- c("movieId", "title", "genres")
movies <- movies %>%
  mutate(movieId = as.integer(movieId))

movielens <- left_join(ratings, movies, by = "movieId")

# Final hold-out test set will be 10% of MovieLens data
set.seed(1, sample.kind="Rounding") # if using R 3.6 or later
# set.seed(1) # if using R 3.5 or earlier
test_index <- createDataPartition(y = movielens$rating, times = 1, p = 0.1, list = FALSE)
edx <- movielens[-test_index,]
temp <- movielens[test_index,]

# Make sure userId and movieId in final hold-out test set are also in edx set
final_holdout_test <- temp %>% 
  semi_join(edx, by = "movieId") %>%
  semi_join(edx, by = "userId")

# Add rows removed from final hold-out test set back into edx set
removed <- anti_join(temp, final_holdout_test)
edx <- rbind(edx, removed)

rm(dl, ratings, movies, test_index, temp, movielens, removed)



glimpse(edx)



#convert empty character spaces to NA
sum(is.na(edx))
sum(is.na(final_holdout_test))



# convert all observations to lower case for uniformity
edx <- data.frame(lapply(edx, tolower))
final_holdout_test <- data.frame(lapply(final_holdout_test, tolower))



# Trim leading and trailing spaces using trimws()
edx$genres <- trimws(edx$genres)
final_holdout_test$genres<- trimws(final_holdout_test$genres)
# Removing vertical bars and replacing with underscores
edx$genres <- gsub("\\|", "_", edx$genres)
final_holdout_test$genres <- gsub("\\|", "_", final_holdout_test$genres)
# Printing the updated strings
#print(edx$genres)



# Define the regex pattern to match movie release years in brackets
regex_p <- "\\s*\\(\\s*[0-9.]+\\s*\\)\\s*"
# Remove numbers in brackets using gsub()
edx$title <- gsub(regex_p, "", edx$title)
final_holdout_test$title <- gsub(regex_p, "", final_holdout_test$title)



# Trim leading and trailing spaces using trimws()
edx$title <- trimws(edx$title)
final_holdout_test$title <- trimws(final_holdout_test$title)
# Replace spaces and commas with underscores from the movie names
edx$title <- gsub(" ", "_", edx$title)
edx$title <- gsub(",", "", edx$title)
edx$title <- gsub("&", "_", edx$title)

final_holdout_test$title <- gsub(" ", "_", final_holdout_test$title)
final_holdout_test$title <- gsub(",", "", final_holdout_test$title)
final_holdout_test$title <- gsub("&", "_", final_holdout_test$title)



#string variables
fact_vars <- c(5,6)
# Correcting factor data types using lapply()
edx[,fact_vars] <- lapply(edx[,fact_vars], as.factor)
final_holdout_test[,fact_vars] <- lapply(final_holdout_test[,fact_vars], as.factor)

# Correct numerical data using lapply()
edx[,-fact_vars] <- lapply(edx[,-fact_vars], as.numeric)
final_holdout_test[,-fact_vars] <- lapply(final_holdout_test[,-fact_vars], as.numeric)




#convert timestamp to date
edx <- edx %>%
  mutate(timestamp = as_datetime(timestamp))
str(edx)

final_holdout_test <- final_holdout_test %>%
  mutate(timestamp=as_datetime(timestamp))



# Extract year of rating for each row using lapply()
rating_years_edx <- lapply(edx$timestamp, format, "%Y")
rating_years_final <- lapply(final_holdout_test$timestamp, format, "%Y")

# Add year column to data frame
edx$year_rating <- unlist(rating_years_edx)
final_holdout_test$year_rating <- unlist(rating_years_final) 
#correcting the newly created variable's datatype
edx$year_rating <- as.numeric(edx$year_rating)
final_holdout_test$year_rating <- as.numeric(final_holdout_test$year_rating)



#Unique values
uniq_values <- lapply(edx, unique)
uniq_value_lens <- lengths(uniq_values)
uniq_value_lens



#set all cases where genres were not listed as missing values
edx$genres[edx$genres=="(no genres listed)"] <- NA
final_holdout_test$genres[final_holdout_test$genres=="(no genres listed)"] <- NA
#omit all observations with missing values
edx <- na.omit(edx)
final_holdout_test <- na.omit(final_holdout_test)
#dimensions of the new cleaned data set
dim(edx)



options(scipen = 999)
#histogram plot of the rating variable
ggplot(edx, aes(x = rating)) +
  geom_histogram(binwidth = 0.5, color = "black", fill = "lightblue") +
  labs(title = "Distribution of Ratings", x = "Rating", y = "Frequency")



# calculate the total number of movies
total_movies <- n_distinct(edx$movieId)
# calculate the number of movies rated more than 4
rated_above_4 <- edx %>%
  filter(rating > 4) %>%
  distinct(movieId) %>%
  nrow()
# calculate the percentage of movies rated more than 4
percent_rated_above_4<- (rated_above_4 / total_movies) * 100
percent_rated_above_4



#compute the highest rated movies by title and order by the number of ratings
top_movies <- edx %>%
  group_by(title) %>%
  summarize(avg_rating = mean(rating, na.rm = TRUE), n_ratings = n()) %>%
  arrange(desc(n_ratings)) %>%
  top_n(10, avg_rating)

kable(top_movies, caption = "Top ten rated movies ordered by the number of ratings")



#Visualize the top 10 rated movies by title
movie_ratings <- edx %>%
  group_by(title) %>%
  summarize(avg_rating = mean(rating, na.rm = TRUE),
            n_ratings = n()) %>%
  arrange(desc(avg_rating)) %>%
  filter(n_ratings >= 20) %>%
  top_n(10, avg_rating)

# Create a bar chart of the top 10 movies by average rating and number of ratings
ggplot(movie_ratings, aes(x = reorder(title, avg_rating), y = avg_rating, fill = n_ratings)) +
  geom_bar(stat = "identity", color = "black", width = 0.5) +
  coord_flip() +
  labs(title = "Top 10 Movies by Average Rating and Number of Ratings",
       x = "Movie Title", y = "Average Rating", fill = "Number of Ratings")



#compute overall genre ratings across all genres regardless of the number of ratings
top_rated_genres <- edx %>%
  group_by(genres) %>%
  summarize(avg_rating = mean(rating, na.rm = TRUE), n_ratings = n()) %>%
  arrange(desc(avg_rating)) %>%
  top_n(10, avg_rating)
kable(top_rated_genres, caption = "Movie genres with the highest average rating")



#compute the average ratings, order by the number of ratings, slice the top 10
top_raters_genres <- edx %>%
  group_by(genres) %>%
  summarize(avg_rating = mean(rating, na.rm = TRUE), n_ratings = n()) %>%
  arrange(desc(n_ratings)) %>%
  top_n(10, avg_rating)

kable(top_raters_genres, caption = "Movie genres with the highest rating with largest number of raters")



#compute top 10 rated movies on average orderd by the number of ratings
top_genres <- edx %>%
  group_by(genres) %>%
  summarize(avg_rating = mean(rating, na.rm = TRUE), n_ratings = n()) %>%
  arrange(desc(avg_rating)) %>%
  top_n(10, avg_rating)
#subset the top ten rated movies from the original dataset
top_genres_ratings <- edx %>%
  filter(genres %in% top_genres$genres) %>%
  group_by(genres, year_rating) %>%
  summarize(avg_rating = mean(rating, na.rm = TRUE))
#line plots of the average ratings of genres over-time
ggplot(top_genres_ratings, aes(x = year_rating, y = avg_rating, color = genres)) +
  geom_line() +
  labs(title = "Average Ratings of Top 10 Genres Over Time", x = "Year of Rating", y = "Average Rating")



#compute the number of ratings as per unique User ID
top_users <- edx %>%
  group_by(userId) %>%
  summarize(n_ratings = n()) %>%
  arrange(desc(n_ratings)) %>%
  top_n(10, n_ratings)
kable(top_users, caption = "Top 10 users with the largest number of ratings")



#visualizing the top 10 movie 'raters'
ggplot(top_users, aes(x = reorder(userId, n_ratings), y = n_ratings)) +
  geom_bar(stat = "identity", fill = "blue") +
  labs(title = "Top 10 Users with Highest Number of Ratings", x = "User ID", y = "Number of Ratings") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))



unique(edx$rating)



# set the seed for reproducibility
set.seed(123)

# randomly subset 0.5% of the edx dataset
train_idx <- sample(nrow(edx), size = round(0.005 * nrow(edx)), replace = FALSE)

# randomly subset 0.5% of the final_hold_out dataset
final_holdout <- sample(nrow(final_holdout_test), size = round(0.005 * nrow(final_holdout_test)), replace = FALSE)

# create the training dataset
train_data <- edx[train_idx, ]

# create the testing dataset
test_data <- final_holdout_test[final_holdout, ]

# Remainder of the edx dataset after excluding the training observations
remainder_edx <- edx[-train_idx, ]

# Remainder of the edx dataset after excluding the training observations
remainder_finalhout <- final_holdout_test[-final_holdout, ]



# specify the formula for the linear regression model
formula <- rating ~ movieId + genres + year_rating
# specify the control for cross-validation
control <- trainControl(method = "cv", number = 3)
# train the model using 3-fold cross-validation
linear_model <- train(formula, data = train_data, method = "lm", trControl = control)
# print the results
print(linear_model)



#predict ratings on the test data
rating_preds <- round(predict(linear_model, newdata = test_data),2)
# calculate the RMSE of the predictions on the test data
lm_rmse <- RMSE(rating_preds, test_data$rating)
lm_rmse



kable(cbind(test_data$rating, rating_preds)[1:10,], 
      col.names = c("Actual rating", "predicted rating"),
      caption = "First 10 Actual vs Predicted rating values")

